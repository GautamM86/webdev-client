import Link from "next/link";

export default function Profile() {
  return (
    <div id="wd-profile-screen">
      <h3>Profile</h3>
      <input defaultValue="alice" placeholder="username" className="wd-username" /> <br />
      <input defaultValue="123" placeholder="password" type="password" className="wd-password" /> <br />
      <input defaultValue="Alice" placeholder="First Name" id="wd-firstname" /> <br />
      <input defaultValue="Wonderland" placeholder="Last Name" id="wd-lastname" /> <br />
      <input defaultValue="2000-01-01" id="wd-dob" type="date" /> <br />
      <input defaultValue="alice@wonderland.com" id="wd-email" type="email" /> <br />
      <select defaultValue="FACULTY" id="wd-role">
        <option value="USER">User</option>
        <option value="ADMIN">Admin</option>
        <option value="FACULTY">Faculty</option>
        <option value="STUDENT">Student</option>
      </select> <br />
      <Link id="wd-signout-btn" href="/account/signin">
        Sign out
      </Link>
    </div>
  );
}