export default function Lab4() {
  return (
    <div>
      <h2>Lab 4</h2>
      <p>Placeholder for future lab content.</p>
    </div>
  );
}